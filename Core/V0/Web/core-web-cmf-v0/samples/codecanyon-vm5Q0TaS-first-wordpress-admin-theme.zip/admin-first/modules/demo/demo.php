<?php
/**
 * @author flatfull.com
 * require $dir . '/modules/demo/demo.php';
 * new Admin_Theme_Demo($setting);
 */

class FFL_Admin_Theme_Demo{

	private $setting;
	function __construct($setting) {
		
	}

}
